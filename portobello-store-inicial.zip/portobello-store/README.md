# PORTOBELLO Store — início do projeto

Protótipo inicial da loja virtual, feito com HTML, CSS e JavaScript usando Vite.

## Requisitos
- Node.js (versão LTS)
- Git
- Conta no GitHub

## Executar localmente
1. Extraia o ZIP.
2. Abra a pasta no VS Code.
3. No terminal, execute:

```bash
npm install
npm run dev
```

4. Abra o endereço local indicado pelo Vite.

## Gerar versão de produção

```bash
npm run build
npm run preview
```

A pasta `dist/` será criada.

## O que já funciona neste protótipo
- Layout responsivo para celular, tablet e computador.
- Filtro demonstrativo de categorias.
- Favoritos temporários durante a sessão.
- Carrinho com quantidades e cálculo do subtotal.
- Interface inicial de newsletter.

## O que ainda NÃO está conectado
- Os produtos e preços são demonstrativos.
- As imagens são referências externas de demonstração.
- Carrinho e favoritos ainda não persistem entre sessões.
- Checkout não envia pedidos.
- Newsletter não armazena contatos.
- Painel administrativo ainda não foi implementado.
- Não há banco de dados nem autenticação.

## Próxima etapa técnica
Configurar um projeto Supabase e implementar:
- Autenticação de usuários administrativos.
- Perfis e papéis (admin, gerente e equipe).
- Políticas de acesso por linha (RLS).
- Tabelas de produtos, variantes, estoque e pedidos.
- Cadastro de newsletter com consentimentos separados para e-mail e WhatsApp.

**Segurança:** nunca coloque chaves secretas ou `service_role` no código do navegador. Use apenas a chave pública apropriada com políticas RLS configuradas. Não publique dados pessoais reais no protótipo.
