import "./styles.css";

const products = [
  { id: 1, name: "Legging Fitness", category: "Feminino", price: 129.90, tag: "Destaque", image: "https://images.unsplash.com/photo-1506619216599-9d16d0903dfd?auto=format&fit=crop&w=900&q=85" },
  { id: 2, name: "Top Fitness", category: "Feminino", price: 69.90, tag: "Novidade", image: "https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&w=900&q=85" },
  { id: 3, name: "Camiseta Esportiva", category: "Masculino", price: 89.90, tag: "", image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=85" },
  { id: 4, name: "Conjunto Training", category: "Feminino", price: 179.90, tag: "Destaque", image: "https://images.unsplash.com/photo-1538805060514-97d9cc17730c?auto=format&fit=crop&w=900&q=85" }
];

const money = value => value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const cart = new Map();
const favorites = new Set();

document.querySelector("#app").innerHTML = `
  <div class="announcement">MODA FITNESS • CONFORTO E ESTILO PARA ACOMPANHAR VOCÊ</div>
  <header class="site-header">
    <a class="brand" href="#" aria-label="PORTOBELLO Store - início">PORTOBELLO<span>STORE</span></a>
    <nav class="desktop-nav" aria-label="Navegação principal">
      <a href="#inicio">Início</a><a href="#produtos">Produtos</a><a href="#sobre">A loja</a>
    </nav>
    <div class="header-actions">
      <button class="icon-button" id="cart-open" aria-label="Abrir sacola">Sacola <span id="cart-count">0</span></button>
      <button class="menu-button" id="menu-toggle" aria-label="Abrir menu">☰</button>
    </div>
  </header>
  <main>
    <section class="hero" id="inicio">
      <div class="hero-copy">
        <p class="eyebrow">PORTOBELLO STORE • MODA FITNESS</p>
        <h1>Seu movimento.<br><em>Seu estilo.</em></h1>
        <p>Peças para acompanhar sua rotina com conforto, praticidade e personalidade.</p>
        <a class="primary-button" href="#produtos">EXPLORAR PRODUTOS <span>↗</span></a>
      </div>
      <div class="hero-image" role="img" aria-label="Imagem ilustrativa de moda esportiva"></div>
      <div class="hero-index">01 <span>—</span> MOVA-SE COM ESTILO</div>
    </section>
    <section class="benefits" aria-label="Diferenciais">
      <div><b>01</b><span>Moda fitness</span></div><div><b>02</b><span>Atendimento próximo</span></div><div><b>03</b><span>Compre pelo WhatsApp</span></div>
    </section>
    <section class="products-section" id="produtos">
      <div class="section-heading"><div><p class="eyebrow">ESCOLHA O SEU ESTILO</p><h2>Produtos em destaque</h2></div><a href="#produtos" class="text-link">VER CATÁLOGO ↗</a></div>
      <div class="filters" role="group" aria-label="Filtrar produtos">
        <button class="filter active" data-filter="Todos">Todos</button><button class="filter" data-filter="Feminino">Feminino</button><button class="filter" data-filter="Masculino">Masculino</button>
      </div>
      <div class="product-grid" id="product-grid"></div>
    </section>
    <section class="newsletter" id="novidades">
      <div><p class="eyebrow">FIQUE POR DENTRO</p><h2>Novidades que<br><em>movimentam você.</em></h2><p>Receba lançamentos e novidades da PORTOBELLO Store.</p></div>
      <form id="newsletter-form" class="newsletter-form">
        <label for="newsletter-email">Seu e-mail</label><input id="newsletter-email" type="email" placeholder="voce@email.com" autocomplete="email" required>
        <label class="consent"><input type="checkbox" required> Aceito receber novidades por e-mail. Poderei cancelar quando quiser.</label>
        <button class="primary-button" type="submit">QUERO RECEBER <span>↗</span></button>
        <small>Protótipo: o cadastro ainda não é enviado nem armazenado.</small>
        <p id="newsletter-feedback" aria-live="polite"></p>
      </form>
    </section>
    <section class="about" id="sobre"><p class="eyebrow">PORTOBELLO STORE</p><h2>Vista sua rotina<br>com personalidade.</h2><p>Moda fitness feminina e masculina. Em breve, mais informações sobre a loja, localização e atendimento.</p></section>
  </main>
  <footer><a class="brand brand-light" href="#">PORTOBELLO<span>STORE</span></a><p>Moda fitness • Porto Belo / Perequê</p><a href="#inicio">Voltar ao topo ↑</a></footer>
  <div class="scrim" id="scrim"></div>
  <aside class="cart-drawer" id="cart-drawer" aria-label="Sacola de compras" aria-hidden="true">
    <div class="drawer-head"><h2>Sua sacola</h2><button id="cart-close" aria-label="Fechar sacola">✕</button></div>
    <div id="cart-items" class="cart-items"><p class="empty-cart">Sua sacola está vazia.</p></div>
    <div class="cart-total"><span>Total dos produtos</span><strong id="cart-total">${money(0)}</strong></div>
    <p class="cart-note">Frete e disponibilidade serão confirmados no atendimento.</p>
    <button class="primary-button checkout" id="checkout">CONTINUAR PELO WHATSAPP ↗</button>
  </aside>
`;

function renderProducts(filter = "Todos") {
  const visible = products.filter(p => filter === "Todos" || p.category === filter);
  document.querySelector("#product-grid").innerHTML = visible.map(p => `
    <article class="product-card">
      <div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy">
        ${p.tag ? `<span class="product-tag">${p.tag}</span>` : ""}
        <button class="favorite ${favorites.has(p.id) ? "is-favorite" : ""}" data-favorite="${p.id}" aria-label="Favoritar ${p.name}">${favorites.has(p.id) ? "♥" : "♡"}</button>
      </div>
      <div class="product-info"><div><p class="product-category">${p.category}</p><h3>${p.name}</h3></div><strong>${money(p.price)}</strong></div>
      <button class="add-button" data-add="${p.id}">ADICIONAR À SACOLA <span>+</span></button>
    </article>`).join("");
}

function renderCart() {
  const entries = [...cart.entries()];
  const count = entries.reduce((sum, [, qty]) => sum + qty, 0);
  const total = entries.reduce((sum, [id, qty]) => sum + products.find(p => p.id === id).price * qty, 0);
  document.querySelector("#cart-count").textContent = count;
  document.querySelector("#cart-total").textContent = money(total);
  document.querySelector("#cart-items").innerHTML = entries.length ? entries.map(([id, qty]) => {
    const p = products.find(item => item.id === id);
    return `<div class="cart-line"><div><b>${p.name}</b><small>${money(p.price)} cada</small></div><div class="qty"><button data-minus="${id}" aria-label="Diminuir quantidade">−</button><span>${qty}</span><button data-plus="${id}" aria-label="Aumentar quantidade">+</button></div></div>`;
  }).join("") : `<p class="empty-cart">Sua sacola está vazia.</p>`;
}

function openCart(open) {
  document.querySelector("#cart-drawer").classList.toggle("open", open);
  document.querySelector("#scrim").classList.toggle("visible", open);
  document.querySelector("#cart-drawer").setAttribute("aria-hidden", String(!open));
}

document.addEventListener("click", event => {
  const add = event.target.closest("[data-add]");
  const favorite = event.target.closest("[data-favorite]");
  const plus = event.target.closest("[data-plus]");
  const minus = event.target.closest("[data-minus]");
  if (add) { const id = Number(add.dataset.add); cart.set(id, (cart.get(id) || 0) + 1); renderCart(); add.textContent = "ADICIONADO ✓"; }
  if (favorite) { const id = Number(favorite.dataset.favorite); favorites.has(id) ? favorites.delete(id) : favorites.add(id); renderProducts(document.querySelector(".filter.active").dataset.filter); }
  if (plus) { const id = Number(plus.dataset.plus); cart.set(id, cart.get(id) + 1); renderCart(); }
  if (minus) { const id = Number(minus.dataset.minus); cart.get(id) <= 1 ? cart.delete(id) : cart.set(id, cart.get(id) - 1); renderCart(); }
  const filter = event.target.closest("[data-filter]");
  if (filter) { document.querySelectorAll(".filter").forEach(b => b.classList.remove("active")); filter.classList.add("active"); renderProducts(filter.dataset.filter); }
});

document.querySelector("#cart-open").addEventListener("click", () => openCart(true));
document.querySelector("#cart-close").addEventListener("click", () => openCart(false));
document.querySelector("#scrim").addEventListener("click", () => openCart(false));
document.querySelector("#menu-toggle").addEventListener("click", () => document.querySelector(".desktop-nav").classList.toggle("mobile-open"));
document.querySelector("#checkout").addEventListener("click", () => {
  if (!cart.size) { alert("Adicione pelo menos um produto à sacola."); return; }
  alert("Próxima etapa: conectar o botão ao WhatsApp oficial da loja. Nenhum pedido foi enviado.");
});
document.querySelector("#newsletter-form").addEventListener("submit", event => {
  event.preventDefault();
  document.querySelector("#newsletter-feedback").textContent = "Formulário demonstrativo. A integração segura será feita na próxima etapa.";
});
renderProducts();
renderCart();
